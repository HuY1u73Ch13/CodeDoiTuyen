#include <bits/stdc++.h>
#define N 100001
#define ll long long
using namespace std;
vector <ll> a, sum;
int n, k, result=0, x;

int _binary(int d, int c, int i)
{
    int p=0;
    while (d <= c)
    {
        int g = (d + c)/2;
        if (a[i] * (i - g + 1) - (sum[i] - sum[g-1]) <= k)
        {
            p = g;
            c = g - 1;
        }
        else d = g + 1;
    }
    return p;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("count.inp","r",stdin);
    freopen("count.out","w",stdout);
    cin >> n >> k;
    a.resize(n+1);
    sum.resize(n+1);
    for (int i=1;i<=n; i++) cin >> a[i];
    sort(a.begin()+1,a.end());
    for (int i=1; i<=n; i++)
        sum[i] = sum[i-1] + a[i]*1ll;
    for (int i=1; i<=n; i++)
    {
        int j = _binary(1,i,i);
        if (result < i - j + 1)
        {
            result = i - j + 1;
            x = a[i];
        }
    }
    cout << result << ' ' << x;
    return 0;
}
