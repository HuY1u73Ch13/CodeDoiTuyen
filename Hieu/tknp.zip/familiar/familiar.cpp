#include <bits/stdc++.h>

using namespace std;
vector <int> a;
int n, res;

bool cmp(int x, int y)
{
    return x > y;
}

bool check(int k)
{
    int x = a[k] + n, amax = 0;
    for (int i=1;i<k;i++)
        amax = max(amax,a[i]+i);
    return x >= amax;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("familiar.inp","r",stdin);
    freopen("familiar.out","w",stdout);
    cin >> n;
    a.resize(n+1);
    for (int i=1; i<=n; i++) cin >> a[i];
    sort(a.begin()+1,a.end(),cmp);
    int d = 1, c = n;
    while (d <= c)
    {
        int g = (d + c)/2;
        if (check(g))
        {
            res = g;
            d = g + 1;
        }
        else c = g - 1;
    }
    cout << res;
    return 0;
}
