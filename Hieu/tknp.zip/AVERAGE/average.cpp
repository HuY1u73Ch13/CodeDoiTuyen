#include <bits/stdc++.h>
#define db double
using namespace std;
const int maxn = 200005;
int n, k;
db a[maxn];

bool ok(db ans)
{
    vector<db> pref_sum(n + 1);
    for (int i = 1; i <= n; i++)
        pref_sum[i] = pref_sum[i-1] + a[i] - ans;

    db min_val = 0;
    for (int i = k; i <= n; i++)
    {
        if (min_val <= pref_sum[i]) return true;
        min_val = min(min_val, pref_sum[i - k + 1]);
    }
    return false;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("average.inp","r",stdin);
    freopen("average.out","w",stdout);
    cin >> n >> k;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        a[i] *= 100000;
    }

    db l = *min_element(a + 1, a + n + 1);
    db r = *max_element(a + 1, a + n + 1);
    db res;
    while (l <= r)
    {
        db mid = (l + r) / 2;
        if (ok(mid))
        {
            res = mid;
            l = mid + 1;
        }
        else
            r = mid - 1;
    }
    cout << fixed << setprecision(3) << res / 100000.0 << endl;
    return 0;
}
