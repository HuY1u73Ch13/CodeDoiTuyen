fi = open("average.inp","r")
n, k = map(int, fi.readline().split())
a = list(map(int,fi.readline().split()))
a = [0] + a
fi.close()

def ok(ans):
    pref_sum = [0] * (n+1)
    for i in range(1,n+1):
        pref_sum[i] = pref_sum[i-1] + a[i] - ans
    min_val = 0
    for i in range(k,n+1):
        if (min_val <= pref_sum[i]): return True
        min_val = min(min_val, pref_sum[i-k+1])
    return False

res = n
for i in range(1,n+1): a[i] *= 100000
l = min(a); r = max(a)
while (l <= r):
    mid = (l + r)//2
    if (ok(mid)):
        res = mid
        l = mid + 1
    else: r = mid - 1

fo = open("average.out","w")
fo.write("%.3f" % (res/100000))
fo.close()
