#include <bits/stdc++.h>
#define N 1000
using namespace std;
vector <int> a;
int dd[2001];
int n, res;

bool check(int k)
{
    memset(dd,0,sizeof(dd));
    for (int i=1;i<=k; i++)
        dd[a[i]]++;
    for (int i=k+1; i<=n; i++)
    if (dd[a[i]] == 0) dd[a[i-k]]--;
    else if (a[i] != a[i-k])
    {
        dd[a[i]]++;
        dd[a[i-k]]--;
    }
    for (int i=0;i<=2000;i++)
    if (dd[i] > 0) return 1;
    return 0;
}
int main()
{
    freopen("rannum.inp","r",stdin);
    freopen("rannum.out","w",stdout);
    cin >> n;
    a.resize(n+1);
    for (int i=1; i<=n; i++)
    {
        cin >> a[i];
        a[i] += N;
    }
    int d = 1, c = n/2+1;
    while (d <= c)
    {
        int g = (d + c)/2;
        if (check(g))
        {
            res = g;
            c = g - 1;
        }
        else d = g + 1;
    }
    cout << res;
    return 0;
}
