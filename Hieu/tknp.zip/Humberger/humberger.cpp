#include <bits/stdc++.h>
#define ll long long
using namespace std;
string s;
ll countb,counts,countc,costb,costs,costc,kq;
ll cb,cs,cc;
ll money;
ll res = 0;
void init()
{
    cb=cs=cc=0;
    for (int i=0; i<s.size();i++)
    if (s[i] == 'B') cb++;
    else    if (s[i] == 'S') cs++;
            else cc++;
}

bool check(ll k)
{
    ll cb1 = 0, cs1 = 0, cc1 = 0, tien = 0;
    //tinh so luong cac nguyen lieu lam ra k chiec banh
    if (cb > 0) cb1 = cb * k;
    if (cs > 0) cs1 = cs * k;
    if (cc > 0) cc1 = cc * k;

    if (cb1 <= countb) cb1 = 0; //neu nguyen lieu trong kho nhieu hon nguyen lieu can thiet thi ko phai mua them
    else cb1 = cb1 - countb; //nguoc lai thi mua them so luong la cb1
    if (cs1 <= counts) cs1 = 0;
    else cs1 = cs1 - counts;
    if (cc1 <= countc) cc1 = 0;
    else cc1 = cc1 - countc;

    tien = cb1 * costb + cs1 * costs + cc1 * costc;
    return tien <= money;
}

int main()
{
    freopen("humberger.inp","r",stdin);
    freopen("humberger.out","w",stdout);
    cin >> s;
    cin >> countb >> counts >> countc;
    cin >> costb >> costs >> costc;
    cin >> money;
    init();
    ll d = 0, c= money+countb+counts+countc;
    while (d <= c)
    {
        ll g =(d + c) / 2;
        if (check(g))
        {
            res = g;
            d = g + 1;
        }
        else c = g - 1;
    }
    cout << res;
    return 0;
}
